import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt,json,zipfile
from matplotlib.ticker import PercentFormatter
from matplotlib.backends.backend_pdf import PdfPages
from pathlib import Path
out=Path('output');out.mkdir(exist_ok=True);stats={}
with PdfPages(out/'Detrended_SP500_Gold.pdf') as pdf:
 for key,title,source in [('spx','S&P 500','Monthly average price index; excludes dividends. Source: Multpl / Shiller.'),('gold','Gold (USD / troy oz)','Monthly average nominal USD price. Source: datasets/gold-prices, World Bank-derived; some values rounded.')]:
  df=pd.read_csv(key+'.csv');dates=pd.to_datetime(df.Date);t=np.arange(len(df))/12;y=np.log(df.Price.to_numpy());X=np.column_stack([np.ones(len(t)),t]);a,b=np.linalg.lstsq(X,y,rcond=None)[0];res=y-X@np.array([a,b]);sig=np.sqrt(res@res/(len(t)-2));dev=np.expm1(res)*100;trend=np.exp(a+b*t)
  assert np.allclose(np.mean(res),0,atol=1e-10) and np.allclose(trend*(1+dev/100),df.Price)
  assert np.all(np.diff(dates.dt.year*12+dates.dt.month)==1)
  df['Trend']=trend;df['Deviation_pct']=dev;df['Z']=res/sig;df.to_csv(out/(key+'_calculations.csv'),index=False)
  stats[key]={'n':len(t),'start':df.Date.iloc[0],'end':df.Date.iloc[-1],'a':a,'b_per_year':b,'sigma_log':sig,'latest_price':float(df.Price.iloc[-1]),'latest_trend':trend[-1],'latest_deviation_pct':dev[-1],'latest_z':res[-1]/sig}
  fig=plt.figure(figsize=(15,7.6),facecolor='white');ax=fig.add_axes([.085,.23,.81,.55]);fig.text(.085,.92,title+' | Detrended',fontsize=27,weight='bold',color='#203247');fig.text(.085,.865,f'{df.Date.iloc[0]} to {df.Date.iloc[-1]}  •  Monthly averages  •  Full-sample exponential trend',fontsize=13,color='#6b7c91');fig.text(.085,.815,f'Latest deviation {dev[-1]:+.1f}%   |   Z-score {res[-1]/sig:+.2f}σ',fontsize=16,weight='bold',color='#203247')
  ax.plot(dates,dev,color='#2b6fc1',lw=2,label='Deviation from trend');ax.axhline(0,color='#818b95',ls='--',label='Trend baseline (0%)')
  for k,c in [(1,'#df8b25'),(2,'#c64b4b'),(-1,'#8abb77'),(-2,'#2e7951')]:ax.axhline(np.expm1(k*sig)*100,color=c,ls='--',lw=1.6,label=f'{k:+d}σ')
  ax.scatter(dates.iloc[-1],dev[-1],color='#2b6fc1',s=25);ax.annotate(f'{dev[-1]:+.1f}%',(dates.iloc[-1],dev[-1]),xytext=(8,0),textcoords='offset points',color='#2b6fc1',weight='bold',va='center');ax.set_xlim(dates.iloc[0],dates.iloc[-1]+pd.Timedelta(days=370));ax.yaxis.set_major_formatter(PercentFormatter());ax.set_ylabel('Deviation from exponential trend (%)',color='#52647b');ax.grid(axis='y',color='#e5eaf0');ax.set_axisbelow(True)
  for s in ['top','right']:ax.spines[s].set_visible(False)
  for s in ['left','bottom']:ax.spines[s].set_color('#ccd6e2')
  ax.tick_params(colors='#6b7c91');ax.legend(loc='upper left',bbox_to_anchor=(0,-.14),ncol=3,frameon=False,fontsize=11);fig.text(.085,.065,source,fontsize=10,color='#6b7c91');fig.text(.085,.035,'Bands: log-residual dispersion (n−2); not confidence intervals. Retrospective fit; price deviation is not fair value.',fontsize=10,color='#6b7c91');fig.savefig(out/(key+'_detrended.png'),dpi=180);pdf.savefig(fig);plt.close(fig)
(out/'model.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats,indent=2))
(out/'Methodology.md').write_text('''# 标普500与黄金 Detrended 图 v1\n生成日期：2026-10-07。\n口径沿用Buffett_AI_Generation_Guide v2：ln(P)=a+bt，OLS全样本回归；sigma=sqrt(sum(residual²)/(n−2))；偏离=100×expm1(residual)；水平σ线=100×expm1(k×sigma)；Z=residual/sigma。\n本次使用真实月均价，不使用季度GDP、市值或总回报；标普不含股息，黄金为名义美元/金衡盎司。未作通胀调整。标普1957-03起，黄金1973-01起以避开固定金价时代。起点和频率不同，因此σ不能视为跨资产绝对风险排名。\n来源：标普 https://www.multpl.com/s-p-500-historical-prices/table/by-month （Multpl/Shiller）；黄金 https://raw.githubusercontent.com/datasets/gold-prices/main/data/monthly.csv （datasets转录World Bank Pink Sheet，发布值部分取整）。截至2026-09；未直接核验最新World Bank XLSX，作为来源透明的观察图使用。\n排除标普2026-10-06当天报价，避免与月均价混用。无插值、无拟合原始价格、无历史缩放。连续性、正值和回算验证通过。\n回归使用截至最新月的全部数据，具有事后视角；新增月份会改变趋势和历史偏离。图中的0%为统计趋势，不是公允价值；超过2σ不等于必然回归或暴跌。后续复用先读当前数据和模型，不静默改变起点或σ定义。\n''')
with zipfile.ZipFile(out/'Detrended_Reproducible.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ['generate.py','spx.csv','gold.csv']:z.write(f)
 for f in out.iterdir():
  if f.suffix in ['.csv','.json','.md']:z.write(f,f.name)
