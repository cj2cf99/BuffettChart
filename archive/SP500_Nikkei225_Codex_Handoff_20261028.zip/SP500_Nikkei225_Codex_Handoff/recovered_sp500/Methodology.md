# 标普500与黄金 Detrended 图 v1
生成日期：2026-10-07。
口径沿用Buffett_AI_Generation_Guide v2：ln(P)=a+bt，OLS全样本回归；sigma=sqrt(sum(residual²)/(n−2))；偏离=100×expm1(residual)；水平σ线=100×expm1(k×sigma)；Z=residual/sigma。
本次使用真实月均价，不使用季度GDP、市值或总回报；标普不含股息，黄金为名义美元/金衡盎司。未作通胀调整。标普1957-03起，黄金1973-01起以避开固定金价时代。起点和频率不同，因此σ不能视为跨资产绝对风险排名。
来源：标普 https://www.multpl.com/s-p-500-historical-prices/table/by-month （Multpl/Shiller）；黄金 https://raw.githubusercontent.com/datasets/gold-prices/main/data/monthly.csv （datasets转录World Bank Pink Sheet，发布值部分取整）。截至2026-09；未直接核验最新World Bank XLSX，作为来源透明的观察图使用。
排除标普2026-10-06当天报价，避免与月均价混用。无插值、无拟合原始价格、无历史缩放。连续性、正值和回算验证通过。
回归使用截至最新月的全部数据，具有事后视角；新增月份会改变趋势和历史偏离。图中的0%为统计趋势，不是公允价值；超过2σ不等于必然回归或暴跌。后续复用先读当前数据和模型，不静默改变起点或σ定义。
