"""Use on a Drive-downloaded baseline. No network fetch, source refresh or refitting."""
import hashlib,json,sys
from pathlib import Path
EXPECTED_SHA256='811a45df3978d0e4e41d85012a737683014f5eba579ba5584a92536e2af68b1a'
def load_frozen(path):
 b=Path(path).read_bytes()
 if hashlib.sha256(b).hexdigest()!=EXPECTED_SHA256:raise ValueError('BASELINE_INTEGRITY_FAILED')
 data=json.loads(b)
 if any(r['is_fitted'] for r in data['rows'] if r['quarter_label']>='1996-10-01'):raise ValueError('OFFICIAL_PERIOD_FIT_FORBIDDEN')
 return data
if __name__=='__main__':
 d=load_frozen(sys.argv[1]);print(json.dumps({'loaded':True,'snapshot':d['snapshot_id'],'rows':len(d['rows'])}))
