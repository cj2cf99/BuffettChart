"""Offline reproducibility only. Production must load frozen Drive snapshot, not run this."""
import csv,json,hashlib
from pathlib import Path
from decimal import Decimal,getcontext
from statistics import median
getcontext().prec=40
ROOT=Path(__file__).resolve().parent
SERIES={'public':'BOGZ1LM883164115Q','total':'BOGZ1LM883164105Q','etf':'BOGZ1FL564090005Q','closed_end':'BOGZ1FL554090005Q','gdp':'GDP'}
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':')).encode()
def build():
 raw={k:{r['observation_date']:r[s] for r in csv.DictReader((ROOT/'raw'/f'{s}.csv').open())} for k,s in SERIES.items()}
 dates=sorted(d for d in raw['gdp'] if '1952-01-01'<=d<='2026-04-01')
 def val(k,d):return Decimal(raw[k][d])
 def ex(k,d):return val(k,d)-val('etf',d)-val('closed_end',d)
 train=[d for d in dates if '1996-10-01'<=d<='2001-07-01']
 factor=median(ex('public',d)/ex('total',d) for d in train)
 rows=[]
 for d in dates:
  q=(int(d[5:7])-1)//3+1;old=d<'1996-10-01'
  cap=ex('total',d)*factor if old else ex('public',d)
  rows.append({'period':f'{d[:4]}Q{q}','quarter_label':d,'period_end':f'{d[:4]}-{q*3:02d}-{30 if q in (2,3) else 31:02d}',
   'market_cap_usd_million':str(cap),'gdp_usd_billion_saar':raw['gdp'][d],
   'buffett_indicator_pct':str(cap/Decimal(1000)/val('gdp',d)*100),
   'quality':'HISTORICAL_ESTIMATE_FROZEN' if old else 'FED_OFFICIAL_DERIVED',
   'is_fitted':old,'is_interpolated':False,'frozen':True,
   'formula':'(total-etf-closed_end)*fixed_public_share' if old else 'public-etf-closed_end',
   'source_values':{s:raw[k][d] for k,s in SERIES.items()}})
 return {'snapshot_id':'buffett_fed_quarterly_1952_2026Q2_v1','captured_on':'2026-10-07',
  'frequency':'quarterly','data_through':'2026Q2','market_scope':'Fed domestic public corporate equities excluding ETF and closed-end funds; pre-1996Q4 reconstructed',
  'exchange_aggregate_equivalence_verified':False,'user_accepted_fed_scope_on':'2026-10-07',
  'history_period':'1952Q1..1996Q3','official_period':'1996Q4..2026Q2',
  'historical_model':{'id':'fixed_public_share_v1','method':'median of (public-etf-closed_end)/(total-etf-closed_end)',
   'training_period':'1996Q4..2001Q3','training_count':len(train),'factor_decimal':str(factor),
   'refit_allowed':False,'uses_recent_ten_years':False,
   'limitation':'Early listed/unlisted shares may differ from calibration era; these are estimates, not observed listed market caps.'},
  'update_policy':{'load_from_drive_first':True,'history_refresh_allowed':False,'existing_rows_rewrite_allowed':False,
   'future_new_quarters_append_only':True,'official_revisions':'record separately; do not overwrite baseline','monthly_interpolation_allowed':False},
  'sources':{s:{'file':f'raw/{s}.csv','url':f'https://fred.stlouisfed.org/series/{s}',
   'sha256':digest((ROOT/'raw'/f'{s}.csv').read_bytes())} for s in SERIES.values()},'rows':rows}
if __name__=='__main__':
 data=build();b=(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode();p=ROOT/'Buffett_Quarterly_Frozen_v1.json'
 if p.exists() and p.read_bytes()!=b:raise ValueError('FROZEN_BASELINE_REWRITE_REFUSED')
 if not p.exists():p.write_bytes(b)
 print(json.dumps({'rows':len(data['rows']),'fitted':sum(r['is_fitted'] for r in data['rows']),'sha256':digest(b)}))
