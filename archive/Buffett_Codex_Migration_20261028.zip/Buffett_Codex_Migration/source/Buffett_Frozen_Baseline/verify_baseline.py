import copy,hashlib,json,tempfile
from pathlib import Path
from decimal import Decimal
from build_baseline import build,canonical,ROOT
from load_frozen import load_frozen
p=ROOT/'Buffett_Quarterly_Frozen_v1.json';d=load_frozen(p);rows=d['rows']
assert d==build()
assert len(rows)==298 and len(set(r['period'] for r in rows))==298
for i,r in enumerate(rows):
 assert int(r['period'][:4])*4+int(r['period'][-1])==1952*4+1+i
 assert r['is_fitted']==(r['quarter_label']<'1996-10-01')
 assert r['gdp_usd_billion_saar']==r['source_values']['GDP']
 assert Decimal(r['market_cap_usd_million'])>0
 if not r['is_fitted']:
  s=r['source_values'];assert Decimal(r['market_cap_usd_million'])==Decimal(s['BOGZ1LM883164115Q'])-Decimal(s['BOGZ1FL564090005Q'])-Decimal(s['BOGZ1FL554090005Q'])
 assert Decimal(r['buffett_indicator_pct'])==Decimal(r['market_cap_usd_million'])/1000/Decimal(r['gdp_usd_billion_saar'])*100
assert not any(r['is_fitted'] for r in rows if r['quarter_label']>='2016-01-01')
with tempfile.TemporaryDirectory() as td:
 t=Path(td)/'tampered.json';t.write_bytes(p.read_bytes()+b' ')
 try:load_frozen(t)
 except ValueError:pass
 else:raise AssertionError('Tampering accepted')
result={'passed':True,'quarterly_rows':298,'historical_estimates':179,'official_derived':119,'protected_recent_rows':42,'missing_values':0,'offline_reproduction_exact':True,'tamper_rejected':True,'figures_generated':0,'history_rows_canonical_sha256':hashlib.sha256(canonical(rows[:179])).hexdigest(),'baseline_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(ROOT/'verification_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
