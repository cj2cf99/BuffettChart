import json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from load_frozen import load_frozen
ROOT=Path(__file__).resolve().parent
rows=load_frozen(ROOT/'input_frozen.json')['rows']
y=np.array([float(r['buffett_indicator_pct']) for r in rows]);t=np.arange(len(y))/4
b,a=np.polyfit(t,np.log(y),1);trend=np.exp(a+b*t);res=np.log(y)-np.log(trend);s=np.sqrt(np.sum(res**2)/(len(y)-2))
recent=rows[-40:];v=y[-40:];tr=trend[-40:];x=np.arange(40)
assert all(not r['is_fitted'] for r in recent) and recent[0]['period']=='2016Q3' and recent[-1]['period']=='2026Q2'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'text.color':'#203247','axes.labelcolor':'#445365','xtick.color':'#607082','ytick.color':'#607082','axes.edgecolor':'#cfd7e0'})
fig,ax=plt.subplots(figsize=(15,7.6),dpi=180);fig.subplots_adjust(left=.085,right=.89,top=.79,bottom=.19)
fig.text(.085,.945,'Buffett Indicator | Recent 10 Years',fontsize=23,weight='bold')
fig.text(.085,.89,'Quarterly observations  •  2016 Q3–2026 Q2  •  Latest published official inputs',fontsize=12,color='#607082')
fig.text(.085,.845,f'Latest {v[-1]:.1f}%   |   Long-term trend {tr[-1]:.1f}%   |   Z-score {res[-1]/s:+.2f}σ',fontsize=14,weight='bold')
colors={1:'#df8b25',2:'#c64b4b',-1:'#8abb77',-2:'#2e7951'}
for k in [2,1,-1,-2]:ax.plot(x,tr*np.exp(k*s),'--',lw=1.6,color=colors[k],label=f'{k:+d}σ (long-term)')
ax.plot(x,tr,'--',lw=1.8,color='#818b95',label='Long-term exponential trend')
ax.plot(x,v,lw=2.3,color='#2b6fc1',marker='o',markersize=4,label='Market value / GDP',zorder=5)
ax.annotate(f'{v[-1]:.1f}%',(39,v[-1]),xytext=(10,0),textcoords='offset points',va='center',color='#2b6fc1',weight='bold')
ticks=[i for i,r in enumerate(recent) if r['period'].endswith('Q1')];ticks=[0]+[i for i in ticks if i<37 and int(recent[i]['period'][:4])%2==0]+[39]
ax.set_xticks(ticks,[recent[i]['period'].replace('Q',' Q') for i in ticks]);ax.set_xlim(-.3,41.1);ax.set_ylim(0,max(v.max(),(tr*np.exp(2*s)).max())*1.08)
ax.set_ylabel('Market Value/GDP (%)',labelpad=12);ax.yaxis.set_major_formatter(PercentFormatter(100,decimals=0));ax.grid(axis='y',color='#e7ebf0',lw=.7);ax.set_axisbelow(True);ax.spines[['top','right']].set_visible(False)
h,l=ax.get_legend_handles_labels();order=[5,4,1,0,2,3];ax.legend([h[i] for i in order],[l[i] for i in order],loc='upper left',bbox_to_anchor=(0,-.09),ncol=3,frameon=False,fontsize=10,columnspacing=2)
fig.text(.085,.047,'Trend and bands use the full 1952 Q1–2026 Q2 model. This is a quarterly view; no 20-month rolling series is plotted.',fontsize=9,color='#687789')
fig.text(.085,.021,'Sources: Federal Reserve public equity less ETF / closed-end funds; BEA / FRED nominal GDP (SAAR). No recent values fitted.',fontsize=9,color='#687789')
fig.savefig(ROOT/'Buffett_Recent_10Y_Quarterly.png');fig.savefig(ROOT/'Buffett_Recent_10Y_Quarterly.pdf')
result={'generated_on':'2026-10-07','start':'2016Q3','end':'2026Q2','points':40,'frequency':'quarterly','monthly_20m_generated':False,'long_term_sigma_method':'log residual; unchanged from existing v1 charts','a':float(a),'b':float(b),'sigma_log':float(s),'latest_bi_pct':float(v[-1]),'baseline_sha256':hashlib.sha256((ROOT/'input_frozen.json').read_bytes()).hexdigest(),'recent_fitted_points':0,'rows':recent,'historical_data_refresh':False}
(ROOT/'recent_chart_values.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Generated recent quarterly chart; 40 points, no fitting of recent observations.')
