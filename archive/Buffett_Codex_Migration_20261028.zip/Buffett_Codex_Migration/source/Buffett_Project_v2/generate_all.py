"""Offline rendering only; Drive/cache orchestration follows Buffett_AI_Generation_Guide.md."""
import subprocess,sys,json,hashlib
from pathlib import Path
from pypdf import PdfWriter,PdfReader
from PIL import Image
r=Path(__file__).resolve().parent
for s in ['generate_charts.py','generate_recent_10y.py']:
 subprocess.run([sys.executable,str(r/s)],check=True)
w=PdfWriter()
for n in ['Buffett_Historical','Buffett_Detrended','Buffett_Recent_10Y_Quarterly']:
 Image.open(r/(n+'.png')).load();w.append(str(r/(n+'.pdf')))
with (r/'Buffett_Three_Charts.pdf').open('wb') as f:w.write(f)
assert len(PdfReader(r/'Buffett_Three_Charts.pdf').pages)==3
recent=json.loads((r/'recent_chart_values.json').read_text());m=json.loads((r/'chart_metrics.json').read_text())
assert recent['points']==40 and len(recent['rows'])==40 and recent['recent_fitted_points']==0
for key,k in [('a','a'),('b','b_per_year'),('sigma_log','sigma_log')]:assert abs(recent[key]-m[k])<1e-12
result={'passed':True,'formal_chart_count':3,'short_frequency':'quarterly','short_points':40,'short_start':recent['start'],'data_through':recent['end'],'shared_model_verified':True,'baseline_unchanged':True,'monthly_target_cancelled':True,'image_decode_verified':True,'combined_pdf_pages':3,'outputs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('*.png')}}
(r/'verification_v2.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
