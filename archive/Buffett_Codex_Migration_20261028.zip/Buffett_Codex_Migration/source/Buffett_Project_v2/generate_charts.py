import json,hashlib,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator,PercentFormatter
from matplotlib.backends.backend_pdf import PdfPages
ROOT=Path(__file__).resolve().parent
from load_frozen import load_frozen
rows=load_frozen(ROOT/'input_frozen.json')['rows']
x=np.array([int(r['period'][:4])+(int(r['period'][-1])-1)/4 for r in rows]);t=x-x[0]
y=np.array([float(r['buffett_indicator_pct']) for r in rows]);log=np.log(y)
b,a=np.polyfit(t,log,1);trend=np.exp(a+b*t);res=log-(a+b*t);sigma=np.sqrt(np.sum(res**2)/(len(y)-2));det=np.expm1(res)*100;z=res/sigma
assert np.isfinite(y).all() and len(y)==298
assert abs(np.mean(res))<1e-10 and abs(np.dot(t,res))<1e-8
assert np.allclose((det/100+1)*trend,y)
colors={1:'#df8b25',2:'#c64b4b',-1:'#8abb77',-2:'#2e7951'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titleweight':'bold','axes.labelcolor':'#445365','text.color':'#203247','axes.edgecolor':'#cfd7e0','xtick.color':'#607082','ytick.color':'#607082','savefig.facecolor':'white'})

def render(kind):
 fig,ax=plt.subplots(figsize=(15,7.6),dpi=160)
 fig.subplots_adjust(left=.085,right=.89,top=.79,bottom=.19)
 title='Buffett Indicator | Historical' if kind=='historical' else 'Buffett Indicator | Detrended'
 fig.text(.085,.945,title,fontsize=23,weight='bold')
 fig.text(.085,.89,'U.S. quarterly data  •  1952 Q1–2026 Q2  •  Frozen baseline v1',fontsize=12,color='#607082')
 latest=y[-1] if kind=='historical' else det[-1]
 summary=(f'Latest {y[-1]:.1f}%   |   Trend {trend[-1]:.1f}%   |   Z-score {z[-1]:+.2f}σ' if kind=='historical' else f'Latest deviation {det[-1]:+.1f}%   |   Z-score {z[-1]:+.2f}σ')
 fig.text(.085,.845,summary,fontsize=14,weight='bold')
 ax.axvspan(1952,1996.75,color='#8391a2',alpha=.075,zorder=0)
 ax.axvline(1996.75,color='#b1bbc7',ls=':',lw=1)
 ax.text(1974,.975,'HISTORICAL ESTIMATE',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=9,color='#768394')
 ax.text(2010,.975,'OFFICIAL FED INPUTS',transform=ax.get_xaxis_transform(),ha='center',va='top',fontsize=9,color='#768394')
 # These are residual dispersion bands, not prediction/confidence intervals.
 for k in [2,1,-1,-2]:
  values=trend*np.exp(k*sigma) if kind=='historical' else np.full(len(x),np.expm1(k*sigma)*100)
  ax.plot(x,values,'--',color=colors[k],lw=1.6,label=f'{k:+d}σ')
 ax.plot(x,trend if kind=='historical' else np.zeros(len(x)),color='#818b95',ls='--',lw=1.8,label='Exponential trend' if kind=='historical' else 'Trend baseline (0%)')
 ax.plot(x,y if kind=='historical' else det,color='#2b6fc1',lw=2.2,label='Market value / GDP' if kind=='historical' else 'Deviation from trend',zorder=5)
 ax.scatter([x[-1]],[latest],color='#2b6fc1',s=32,zorder=6)
 ax.annotate(f'{latest:.1f}%' if kind=='historical' else f'{latest:+.1f}%',(x[-1],latest),xytext=(9,0),textcoords='offset points',va='center',fontsize=11,color='#2b6fc1',weight='bold')
 ax.set_xlim(1952,2027.5)
 if kind=='historical':ax.set_ylim(0,max(np.max(y),np.max(trend*np.exp(2*sigma)))*1.1)
 else:
  allv=np.r_[det,[np.expm1(k*sigma)*100 for k in [-2,-1,1,2]]];ax.set_ylim(np.min(allv)-15,np.max(allv)+22)
 ax.set_ylabel('Market Value/GDP (%)' if kind=='historical' else 'Deviation from exponential trend (%)',labelpad=12)
 ax.yaxis.set_major_formatter(PercentFormatter(xmax=100,decimals=0));ax.xaxis.set_major_locator(MultipleLocator(10))
 ax.grid(axis='y',color='#e7ebf0',lw=.7);ax.set_axisbelow(True)
 ax.spines[['top','right']].set_visible(False)
 h,l=ax.get_legend_handles_labels();order=[5,4,1,0,2,3]
 ax.legend([h[i] for i in order],[l[i] for i in order],loc='upper left',bbox_to_anchor=(0,-.09),ncol=3,frameon=False,fontsize=10,columnspacing=2)
 fig.text(.085,.047,'Shaded history: 179 frozen estimates before 1996 Q4. Thereafter: Fed public equity less ETF / closed-end funds.',fontsize=9,color='#687789')
 fig.text(.085,.021,'Sources: Federal Reserve Financial Accounts; BEA / FRED nominal GDP (SAAR). Bands: log-residual dispersion, not confidence intervals.',fontsize=9,color='#687789')
 fig.savefig(ROOT/f'Buffett_{kind.title()}.png',dpi=180)
 fig.savefig(ROOT/f'Buffett_{kind.title()}.pdf')
 return fig
figs=[render('historical'),render('detrended')]
with PdfPages(ROOT/'Buffett_Long_Term_Charts.pdf') as pdf:
 for fig in figs:pdf.savefig(fig)
metrics={'baseline_sha256':hashlib.sha256((ROOT/'input_frozen.json').read_bytes()).hexdigest(),'n':len(y),'model':'ln(BI)=a+b*t; full available history fit as of 2026Q2; expanding sample on future new quarters, not point-in-time historical forecasts','a':float(a),'b_per_year':float(b),'sigma_log':float(sigma),'sigma_ddof':2,'latest_period':rows[-1]['period'],'latest_bi_pct':float(y[-1]),'latest_trend_pct':float(trend[-1]),'latest_deviation_pct':float(det[-1]),'latest_z_score':float(z[-1]),'detrended_horizontal_bands_pct':{str(k):float(np.expm1(k*sigma)*100) for k in [-2,-1,1,2]},'history_rows_modified':False,'quarterly_chart_count':2,'monthly_chart_generated':False,'monthly_blocker':'Monthly 20M target cancelled; see authoritative project_config.json','checks':{'baseline_hash_pass':True,'OLS_residual_orthogonality_pass':True,'detrending_round_trip_pass':True}}
(ROOT/'chart_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
chartrows=[dict(r,trend_pct=float(trend[i]),detrended_pct=float(det[i]),z_score=float(z[i]),bands_pct={str(k):float(trend[i]*np.exp(k*sigma)) for k in [-2,-1,1,2]}) for i,r in enumerate(rows)]
(ROOT/'chart_values.json').write_text(json.dumps(chartrows,indent=2)+'\n')
print(json.dumps(metrics))
